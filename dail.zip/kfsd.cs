using UnityEngine;
public class Chip : MonoBehaviour
{
    public float Speed;
    public float DirectionX, DirectionY;
    void Update()
    {
        MoveAndJump();
    }
    void MoveAndJump()
    {
        DirectionX = Input.GetAxis("Horizontal");
        DirectionY = Input.GetAxis("Vertical");
        Vector2 movement = new Vector2(DirectionX, DirectionY);
        transform.Translate(movement * Speed * Time.deltaTime);
    }
}